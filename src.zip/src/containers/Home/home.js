
import { Route, Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      <h1>Home</h1>
    <button><Link to="/therapy">Therapy</Link></button>
    </div>
  );
}

export default Home;